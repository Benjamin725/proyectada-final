import { Component } from '@angular/core';
import { NgClass } from '@angular/common';
@Component({
  selector: 'app-nosotros',
  imports: [NgClass],
  templateUrl: './nosotros.html',
  styleUrl: './nosotros.css',
})
export class Nosotros {
  nombre: string = 'Bentru7';
  usuario: string = '@bentru7';
  urlFoto: string = 'https://picsum.photos/seed/perfil/120/120';
  estaOnline: boolean = true;

  // Alterna el estado online/offline
  toggleOnline(): void {
    this.estaOnline = !this.estaOnline;
  }
}
