import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

interface Juego {
  id: number;
  nombre: string;
  imagen: string;
  precio: number;
  precioOferta?: number;
  descuentoPorcentaje?: number;
  tipo: 'nuevo' | 'oferta';
  desarrollador: string;
  rating: number;
}
@Component({
  selector: 'app-inicio',
  imports: [RouterLink,CommonModule],
  templateUrl: './inicio.html',
  styleUrl: './inicio.css',
})
export class Inicio {
juegoNuevo: Juego = {
    id: 1,
    nombre: '007 First Light ',
    imagen: 'https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/3768760/dbe86ebd2edb4c77d113e9e2feefeb90189fabc9/header.jpg?t=1780990824',
    precio: 59.99,
    desarrollador: 'IO Interactive',
    rating: 10.0,
    tipo: 'nuevo',
  };

  juegoNuevos: Juego[] = [
    {
      id: 2,
      nombre: 'Forza Horizon 6',
      imagen: 'https://tse3.mm.bing.net/th/id/OIP.dLfIdHefSQIW5ejrewxEKgHaEK?cb=thfc1falcon2&rs=1&pid=ImgDetMain&o=7&rm=3',
      precio: 69.99,
      desarrollador: 'Playground Games',
      rating: 9.8,
      tipo: 'nuevo',
    },
    {
      id: 3,
      nombre: 'Subnautica 2',
      imagen: 'https://tse1.mm.bing.net/th/id/OIP.KldEZxdaUyNWh6HFo3dQsgHaEK?cb=thfc1falcon2&rs=1&pid=ImgDetMain&o=7&rm=3',
      precio: 19.99,
      desarrollador: 'Unknown Worlds Entertainment',
      rating: 8.9,
      tipo: 'nuevo',
    },
    {
      id: 4,
      nombre: 'DOOM The Dark Ages',
      imagen: 'https://blogs.nvidia.com/wp-content/uploads/2025/05/gfn-thursday-doom-tda-nv-blog-1280x680-logo-960x510.jpg',
      precio: 44.99,
      desarrollador: 'id Software',
      rating: 10.0,
      tipo: 'nuevo',
    },
    {
      id: 5,
      nombre: 'Hytale',
      imagen: 'https://tse3.mm.bing.net/th/id/OIP.vVIkH2I7B4bK7koK8tbJeQHaEK?cb=thfc1falcon2&w=1920&h=1080&rs=1&pid=ImgDetMain&o=7&rm=3',
      precio: 39.99,
      desarrollador: 'Hypixel Studios',
      rating: 6.9,
      tipo: 'nuevo',
    },
  ];

  juegoOferta: Juego[] = [
    {
      id: 6,
      nombre: 'Cyberpunk 2077',
      imagen: 'https://image.api.playstation.com/vulcan/ap/rnd/202311/2812/ae84720b553c4ce943e9c342621b60f198beda0dbf533e21.jpg',
      precio: 39.99,
      precioOferta: 9.99,
      descuentoPorcentaje: 75,
      desarrollador: 'Royal Games',
      rating: 4.3,
      tipo: 'oferta',
    },
    {
      id: 7,
      nombre: 'Minecraft',
      imagen: 'https://i.pinimg.com/736x/a6/bc/10/a6bc10fb39ad2a528d6e3b25d1fff6cc.jpg',
      precio: 29.99,
      precioOferta: 7.49,
      descuentoPorcentaje: 75,
      desarrollador: 'Mojang Studios',
      rating: 10.0,
      tipo: 'oferta',
    },
    {
      id: 8,
      nombre: 'Crysis Remastered Trilogy',
      imagen: 'https://tse2.mm.bing.net/th/id/OIP._m74cambsY4ZaUCY0eRCmwHaEK?cb=thfc1falcon2&rs=1&pid=ImgDetMain&o=7&rm=3',
      precio: 15.99,
      precioOferta: 9.99,
      descuentoPorcentaje: 38,
      desarrollador: 'Hell Studios',
      rating: 4.5,
      tipo: 'oferta',
    },
    {
      id: 9,
      nombre: 'Moto GP 26',
      imagen: 'https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/3875050/b53a48a0eb23496725d62cd610096ce95a8491f1/header.jpg?t=1774084021',
      precio: 24.99,
      precioOferta: 10.99,
      descuentoPorcentaje: 59,
      desarrollador: 'Milestone S.r.l',
      rating: 7.9,
      tipo: 'oferta',
    },
    {
      id: 10,
      nombre: 'The Sons Of The Forest',
      imagen: 'https://thf.bing.com/th/id/R.ebb3ab286a4df8e9cce120526f6d26f7?rik=W6MtOhOiShSSDA&pid=ImgRaw&r=0',
      precio: 19.99,
      precioOferta: 3.99,
      descuentoPorcentaje: 80,
      desarrollador: 'Endnight Gmaes Ltd',
      rating: 4.1,
      tipo: 'oferta',
    },
  ];

  verTodos(): void {
    // Navegar a productos
    window.location.href = '/productos';
  }

  agregarAlCarrito(juego: Juego): void {
    console.log('Agregado al carrito:', juego.nombre);
    alert(`${juego.nombre} fue agregado al carrito`);
  }
}
