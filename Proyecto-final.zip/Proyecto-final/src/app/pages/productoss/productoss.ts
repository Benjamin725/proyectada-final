
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductoCard } from '../../components/producto-card/producto-card';
import { Producto } from '../../models/producto/producto';

interface Juego {
  id: number;
  nombre: string;
  imagen: string;
  tipo: 'Nuevo' | 'Viejo';
  desarrollador: string;
  rating: number;
}
@Component({
  selector: 'app-productoss',
  imports: [CommonModule, ProductoCard],
  templateUrl: './productoss.html',
  styleUrl: './productoss.css',
})
export class Productoss {
  juegosbiblioteca: Juego[] = [
    {
      id: 1,
      nombre: 'Half Life',
      imagen: 'https://tse3.mm.bing.net/th/id/OIP.9HW8BZ32cclv0sheqoZq3AHaEP?cb=thfvnextfalcon2&rs=1&pid=ImgDetMain&o=7&rm=3',
      desarrollador: 'Valve',
      rating: 9.1,
      tipo: 'Viejo',
    },
    {
      id: 2,
      nombre: 'Plants VS Zombies Garden Warfare',
      imagen: 'https://tse3.mm.bing.net/th/id/OIP.b1hg2b1HbqmXsWV71P7zZAHaEK?cb=thfvnextfalcon2&rs=1&pid=ImgDetMain&o=7&rm=3',
      desarrollador: 'EA',
      rating: 8.7,
      tipo: 'Viejo',
    },
    {
      id: 3,
      nombre: 'Cuphead',
      imagen: 'https://static0.gamerantimages.com/wordpress/wp-content/uploads/2020/07/cuphead-mugman-title-screen.jpg',
      desarrollador: 'MDHR Studio',
      rating: 8.4,
      tipo: 'Viejo',
    },
    {
      id: 4,
      nombre: 'TABS',
      imagen: 'https://thfvnext.bing.com/th/id/R.5a7fa2ad3029ef94c70ca19f088ee9c3?rik=DlKBRm2wfNmOcg&pid=ImgRaw&r=0',
      desarrollador: 'Landfall Games',
      rating: 8.7,
      tipo: 'Viejo',
    },
    {
      id: 5,
      nombre: 'Assassin Creed Black Flag Resynced',
      imagen: 'https://cdn.wccftech.com/wp-content/uploads/2026/04/Assassins-Creed-Black-Flag-Resynced-Leaked-Footage-Shadows-Visuals-1920x1039.jpg',
      desarrollador: 'Ubisoft',
      rating: 8.9,
      tipo: 'Nuevo',
    },
  ];

 onAgregar(producto: Producto): void {
    console.log('Agregado al carrito:', producto.nombre);
    alert(`${producto.nombre} fue agregado al carrito por $${producto.precio}`);
  }
  jugar(juego: Juego): void {
    console.log('Iniciando juego:', juego.nombre);
    alert(`🎮 ¡Iniciando ${juego.nombre}!`);
  }
}