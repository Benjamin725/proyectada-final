import { Component } from '@angular/core';

@Component({
  selector: 'app-productoss',
  imports: [],
  templateUrl: './productoss.html',
  styleUrl: './productoss.css',
})
export class Productoss {
}
