import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-contactos',
  imports: [CommonModule],
  templateUrl: './contactos.html',
  styleUrl: './contactos.css',
})
export class Contactos {
  empresa = {
    nombre: 'SteamHub Games',
    telefono: '+54 9 11 2345-6789',
    email: 'contacto@steamhubgames.com',
    foto: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRKRPBSKE85Ip3586MjyfYNKziWIZhRkFPilav5755P3g&s=10',
    descripcion: 'Tu tienda de juegos en línea favorita',
    direccion: 'Buenos Aires, Argentina',
  };
}