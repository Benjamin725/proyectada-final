import { Routes } from '@angular/router';
import { Inicio } from './pages/inicio/inicio';
import { Contactos } from './pages/contactos/contactos';
import { Nosotros } from './pages/nosotros/nosotros';
import { NotFound } from './pages/not-found/not-found';
import { Productoss } from './pages/productoss/productoss';

export const routes: Routes = [
  { path: '',          component: Inicio },
  { path: 'contacto',  component: Contactos },
  { path: 'nosotros',  component: Nosotros },
  { path: 'productos', component: Productoss },
  { path: '**',        component: NotFound },
];