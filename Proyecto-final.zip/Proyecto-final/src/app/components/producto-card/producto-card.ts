import { Component } from '@angular/core';
import { Producto } from '../../models/producto/producto';

@Component({
  selector: 'app-producto-card',
  imports: [ProductoCard],
  templateUrl: './producto-card.html',
  styleUrl: './producto-card.css',
})
export class ProductoCard {


}
