import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Producto } from '../../models/producto/producto';
@Component({
  selector: 'app-producto-card',
  imports: [CommonModule],
  templateUrl: './producto-card.html',
  styleUrl: './producto-card.css',
})
export class ProductoCard {
  @Input() producto!: Producto;
  @Output() agregarAlCarrito = new EventEmitter<Producto>();

  onAgregar() {
    this.agregarAlCarrito.emit(this.producto);
  }
}