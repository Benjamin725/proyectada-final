import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Footer } from './components/footer/footer';
import { Navbar } from './components/navbar/navbar';
import { Inicio } from './pages/inicio/inicio';
@Component({
  selector: 'app-root',
  imports: [Navbar,Footer,RouterOutlet,Inicio],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('Proyecto-final');


}
