import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Footer } from './components/footer/footer';
import { Navbar } from './components/navbar/navbar';
import { Inicio } from './pages/inicio/inicio';
@Component({
  selector: 'app-root',
  imports: [Navbar,Footer,RouterOutlet,Inicio],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('Proyecto-final');


  el fondo que sea negro con gris y las cards las letras y el puntaje y el nombre que esten en
   un blaco no tan blanco tambien en la parte de el precio de descuento y el precio que estaba antes ponlo en verde 
   y el precio tachado en verde oscuro, y deja todo bien prolijo y aestetic.}
