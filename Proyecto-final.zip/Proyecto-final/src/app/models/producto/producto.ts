export interface Producto {
  nombre: string;
  usuario: string;
  urlFoto: string ;
  estaOnline: boolean;
}

