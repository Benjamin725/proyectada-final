export interface Producto {
  nombre: string;
  usuario: string;
  precio:number;
  urlFoto: string ;
  estaOnline: boolean;
}

